<html>
<body  LEFTMARGIN=30 TOPMARGIN=0 RIGHTMARGIN=30 BOTTOMMARGIN=0 BGCOLOR="AliceBlue">
	
<footer>
		<table border="1px" width = "100%" >
			<td align = "justify" valign="top"> <p><b>TRỤ SỞ HÀ NỘI</b><br>
													 Tầng 01 nhà A trường Đại học Hà Nội,<br>
													 Km 9, Nguyễn Trãi, Q.Thanh Xuân, <br>
													 t.p Hà Nội.<br>
									 				<b>LIÊN HỆ</b><br>
									 				(84-24) 38 544 338<br>
												</p>
			</td>
			<td align = "justify" valign = "top"> <p><b>NHÀ SÁNG LẬP WEB</b><br>
														Phạm Thanh Hoa<br>
														Trần Ngọc Huyền
												</p>
			
			</td>
			<td align = "justify" valign = "top"> <p><b>VẬN HÀNH BỞI</b><br>
														Khoa Công Nghệ Thông Tin<br>
														trường Đại học Hà Nội.
												</p>
			</td>		


		</table>
</footer>


</body>
</html>