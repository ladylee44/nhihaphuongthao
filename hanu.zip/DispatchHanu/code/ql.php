<?php
	include("header.php");
?>
<br>
<br>
<table align="center" border="1px">
	<tr>
		<td><a href= "quanlytv.php">Quản lý thành viên</a></td>
	</tr>
	<tr>
		<td><a href="suaAd.php">Chỉnh sửa admin</a></td>
	</tr>
    <tr>
    	<td><a href="themTV.php">Thêm thành viên</a></td>
    </tr>
	<tr>
		<td><a href="homepage.php">Quay lại</a></td>
	</tr>
</table>
<br>
<br>
<?php
	include("footer.php");
?>