<nav>
			<div class="innertube">

				<h3>News</h3>
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="hotnews.php">Most Viewed News</a></li>
					<li><a href="editprofile.php">Edit profile</a></li>
						<li><a href="userprofile.php"> Profile</a></li>


					
				</ul>

				<h3>Photo Albums</h3>
				<ul>
					<li><a href="nikealbum.php">Nike</a></li>
					<li><a href="jordanalbum.php">Jordan</a></li>
					<li><a href="converse.php">Converse</a></li>
					


					
				</ul>

				<h3>Read by Brands</h3>
				<ul>
					<li><a href="nike.php">Nike</a></li>
					<li><a href="jordan.php">Jordan</a></li>
					<li><a href="converse.php">Converse</a></li>


					
				</ul>

				<h3>Follow us on:</h3>
				<ul>
					<li><a href="https://instagram.com/sneakernews">Instagram</a></li>
					<li><a href="https://www.facebook.com/sneakernews">Facebook</a></li>
					<li><a href="https://twitter.com/sneakernews">Twitter</a></li>
					<li><a href="https://www.youtube.com/user/sneakernews?sub_confirmation=1">Youtube</a></li>

					
				</ul>
				<h3>Advertise</h3>
				<ul>
					<li><p>If you are looking to purchase above the fold advertisements on Sneaker News, please visit Complex Media Network. Sneaker News is now also accepting select smaller brands and retailers. Only 125×125 ads are available on a bi-monthly basis. Please contact us for more info.</p></li>
					
				</ul>
				<h3>About</h3>
				<ul>
					<li><p>For all general inquries please email here:
						kicks@sneakernews.com ATTENTION SEO MARKETERS:
						We do not accept SEO link additions unless your
						 budget is over $10,000USD.

				</ul>
			</div>
		</nav>l