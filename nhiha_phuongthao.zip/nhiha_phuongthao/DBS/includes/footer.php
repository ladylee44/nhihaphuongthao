</div>
		
	<footer>
		<div class="innertube">
			<p></p>
		</div>
		<script type="text/javascript">
    //cmnTB();    // Toolbar
    cmnUNT('tover', tile_num++);
</script>
<script type="text/javascript">document.write(unescape("%3Cscript src='" + (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js' %3E%3C/script%3E"));</script>
<script type="text/javascript">
    COMSCORE.beacon({
        c1: 2,
        c2: 6685975,
        c3: "",
        c4: "www.sneakernews.com/",
        c5: "",
        c6: "",
        c15: ""
    });
</script>
<noscript><img src="http://b.scorecardresearch.com/p?c1=2&c2=6685975&c3=&c4=&c5=&c6=&c15=&cj=1"
               alt="score card research"/></noscript>
<!-- End comScore Tag -->

<script type="text/javascript">
    (function () {
        window.cToolbarInit = function () {
            cToolbar.load({
                mobileRightButton: 'email',
                facebookUsername: 'sneakernews',
                facebookName: 'sneakernews.com',
                twitterHandle: 'sneakernews',
                twitterName: 'SneakerNews.com',
                youtubeChannel: '',
                youtubeChannelName: '',
                desktopBackground: 'solid',
                desktopSocialButtons: ["twitter", "facebook"],
                channel: '',
                disableMobile: true
            });
        };

        var ns = document.createElement('script');
        ns.type = 'text/javascript';
        ns.async = true;
        ns.src = '//toolbar.complex.com/dist/ctoolbar.min.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ns, s);
    })();
    window._pp = window._pp || [];
    _pp.siteId = 1094;
    (function () {
        var ppjs = document.createElement('script');
        ppjs.type = 'text/javascript';
        ppjs.async = true;
        ppjs.src = ('https:' == document.location.protocol ? 'https:' : 'http:') +
            '//cdn.pbbl.co/r/' + _pp.siteId + '.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ppjs, s);
    })();
</script>

<div id="fb-root"></div>
<script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.11&appId=153012592016434';
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"949ceaf672","applicationID":"59330863","transactionName":"MQZWYhAFXhdYAUBfWwhMdVUWDV8KFgtaUlEe","queueTime":0,"applicationTime":234,"atts":"HUFBFFgfTUgbAxYMTxse","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>

	</footer>
</body>
</html>