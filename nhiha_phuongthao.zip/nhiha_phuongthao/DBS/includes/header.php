<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

		<meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="https://sneakernews.com/wp-content/themes/sneakernews/images/favicon-144.png">
    <meta name="msapplication-config" content="https://sneakernews.com/wp-content/themes/sneakernews/images/browserconfig.xml">
    <meta property="fb:app_id" content="153012592016434" />

		<title>Sneakers News</title>
		<link rel="stylesheet" type="text/css" href="style/style.css">

		 <link rel="shortcut icon" type="image/png" sizes="32x32" href="https://sneakernews.com/wp-content/themes/sneakernews/images/favicon_icon.png">
		
</head>
	
<body>		
 
	<header>
		<div class="innertube">
			<h3></h3>
		</div>
		<div align = "center">
		<div class="header-main">
            <div class="wrapper">
                <div class="site-logo">
                    <a href="index.php">
						<img src="https://sneakernews.com/wp-content/themes/sneakernews/images/site-logo.png" class="" alt="default logo image">                    </a>
                    
                </div><!-- site-logo -->
                        </div></div>

        <div align = "right">
        <div class="header-search">
                            <a href="#" class="search-icon">
                            </a>
							<form role="search" method="get"  action="search.php">
	<label>
		<span class="screen-reader-text"></span>
	
		<i class="close-btn"></i>
	</label>
	<button type="submit" class="search-submit"><span class="screen-reader-text">Search</span></button>

    
</form>                        </div><!-- header-search -->
                    </div><!-- header-top -->
                    </div>
                        
						
                                        
	</header>
		
	<div id="wrapper">
	
		<main>
			<div id="content">