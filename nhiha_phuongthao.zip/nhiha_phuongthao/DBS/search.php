<!doctype html>
<html>
<head> 
	<meta charset = "utf-8">
	<title> Search</title>

	<link rel="stylesheet" href=" = "css/main.css">
</head>
<body>
	<form action = "search1.php" method = "get">
		<label>
			Search 
			<input type="text" name="keywords" autocomplete="off">
		</label>

		<input type="submit" value="Search">
	</form>
</body>
</html>