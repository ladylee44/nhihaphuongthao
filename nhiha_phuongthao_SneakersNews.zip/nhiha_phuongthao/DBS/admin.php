<?php include "includes/header.php" ?>
<html>
<table border = 1>
	<h2>Member Management</h2>
		<a href = "editmember.php">Edit Members'Info</a><br/>
		<a href = "addmember.php">Add New Member</a><br/>
	<h2>Posts Management</h2>
		<a href = "addnewpost.php">Add New Post<br/>
		<a href = "index.php">Go to Homepage<br/>

		
</html>
<?php include "includes/sidebar.php" ?>
<?php include "includes/footer.php" ?>